#!/usr/bin/env python3
"""Generate Android launcher PNGs from repository-root app-icon.png.
If app-icon.png is not present, generate a deterministic fallback icon.
"""
from pathlib import Path
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "app-icon.png"
RES = ROOT / "app/src/main/res"
SIZES = {"mdpi": 48, "hdpi": 72, "xhdpi": 96, "xxhdpi": 144, "xxxhdpi": 192}

if SOURCE.exists():
    im = Image.open(SOURCE).convert("RGBA")
    # Fit the artwork to a square canvas without stretching it.
    side = max(im.size)
    canvas = Image.new("RGBA", (side, side), (30, 20, 60, 255))
    canvas.alpha_composite(im, ((side-im.width)//2, (side-im.height)//2))
else:
    side = 512
    canvas = Image.new("RGBA", (side, side), (30, 20, 60, 255))
    d = ImageDraw.Draw(canvas)
    d.rounded_rectangle((28, 28, 484, 484), radius=112, fill=(45, 30, 90, 255), outline=(145, 100, 255, 255), width=10)
    d.ellipse((110, 110, 402, 402), outline=(95, 225, 255, 255), width=16)
    # Simple white LifeOS monogram fallback.
    try:
        from PIL import ImageFont
        font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 150)
    except OSError:
        font = ImageFont.load_default()
    bbox = d.textbbox((0, 0), "L", font=font)
    d.text(((side-(bbox[2]-bbox[0]))/2, (side-(bbox[3]-bbox[1]))/2-bbox[1]), "L", font=font, fill=(255,255,255,255))

for density, size in SIZES.items():
    outdir = RES / f"mipmap-{density}"
    outdir.mkdir(parents=True, exist_ok=True)
    canvas.resize((size, size), Image.Resampling.LANCZOS).save(outdir / "ic_launcher.png", optimize=True)
print("Launcher icons generated from app-icon.png" if SOURCE.exists() else "Fallback launcher icons generated; add app-icon.png to use your own icon.")
