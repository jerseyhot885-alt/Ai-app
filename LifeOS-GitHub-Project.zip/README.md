# LifeOS Android

LifeOS is a local-first Android WebView application for personal organization, study tracking, planning and lightweight gamification.

## Project details
- Android application ID: `com.lifeos.app`
- Version: `1.0.0` (versionCode 1)
- Minimum Android: API 23 (Android 6.0)
- Java: 17
- Android Gradle Plugin: 8.7.3
- Compile SDK: 35
- All app HTML/CSS/JavaScript is bundled under `app/src/main/assets/index.html`; the app does not need a website or internet connection to run.
- Data is stored locally in WebView localStorage. Uninstalling the app or clearing its storage deletes that data.

## Build an APK using only an Android phone
1. Download and extract `LifeOS-project.zip` with your phone's Files app or a ZIP extractor.
2. Open https://github.com in your phone browser and sign in.
3. Create a new repository named `LifeOS`. A private repository is fine. Do not initialize it with a README or license because the project already has files.
4. Upload the **contents** of the extracted `LifeOS` folder to the repository root. Ensure `.github/workflows/build-LifeOS.yml` is included. If GitHub's mobile upload flow hides dot-folders or will not upload folders, use GitHub's browser desktop-site option or upload the ZIP only as a temporary file and extract/upload the contents using a phone-friendly Git client. The workflow must end up at the exact path `.github/workflows/build-LifeOS.yml` in the repository.
5. Commit the upload to the `main` branch.
6. Open the repository's **Actions** tab. Select **Build LifeOS APK**, then **Run workflow** if it has not already started automatically after your push.
7. Wait for the run to finish with a green check. Open the run and find **Artifacts** near the bottom. Download `LifeOS-debug-apk`.
8. Extract the artifact ZIP on your phone. It contains `app-debug.apk`.
9. Tap `app-debug.apk`. If Android asks, allow your browser or file manager to install unknown apps, then return and install. Only install APKs you built from a repository you trust.
10. Open LifeOS. Test profile editing, add a task, complete a daily habit, close and reopen the app to verify persistence. To test a clean reset, go to Settings and use **Reset All LifeOS Data** after confirming twice.

## Build from a computer (optional)
With JDK 17 and Gradle installed, run `gradle assembleDebug` from the repository root. APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## Implemented modules
- Dashboard/profile summary, rank/level/XP/points/HP, daily habits, weekly quest, shortcuts and progress graph.
- Editable profile (name, title, initials, bio) with local persistence.
- Daily habit rewards (maximum 3 active habits), daily full-clear bonus, weekly quest bonus, duplicate-claim prevention and completion reversal.
- Configurable core point rules, editable three daily habit names and weekly quest, HP, and reset-all confirmation.
- Separate modules for events, time/activity, I Owe & I Get, daily executive order/to-do, problems & doubts, planner/advisor, inventory/to-buy, abilities/rank-up quests, subject revision, targets, contacts, achievements and daily notes.
- Create, edit and delete records; subject revision count controls; offline rule-based planning advisor.
- Local progress history and a simple historical graph.
- Android WebView wrapper loading `file:///android_asset/index.html`.
- GitHub Actions debug APK workflow.

## QA and known limitations
Checks performed before packaging: project file paths and required workflow are present; HTML file has a complete document structure; source was inspected for the local WebView URL and app ID. A full Android Gradle build was not run in this environment, so APK compilation is **not yet verified**. GitHub Actions is intended to perform that build and will report compilation failures visibly.

Known limitations:
- This is a functional first version, not a fully native Compose UI. The interface is HTML/CSS in Android WebView.
- No cloud sync, account, map provider, push notifications, image avatar upload, or data export/import yet.
- Rank names and later level thresholds are intentionally lightweight; later thresholds can be configured in settings data, but a dedicated editor for every level is not yet provided.
- LocalStorage data can be lost if app storage is cleared or the app is uninstalled. Back up important data manually until export is added.
- Daily/weekly records use the device's local date and browser storage; this version does not include a separate background reset service.
- Test on the target phone after installing. Android versions and GitHub's mobile upload interface may vary.


## Use your own Android app icon

1. The supplied `app-icon.png` is already included. If you want to replace it later, use a square PNG (recommended 512×512 or 1024×1024). Transparent backgrounds are supported. Avoid putting important details right at the edges because Android launchers may mask icons into different shapes.
2. Upload the image to the **repository root** and name it exactly `app-icon.png` (same level as `settings.gradle` and `build.gradle`). Do not put it inside `app/src`.
3. Commit the file to the `main` branch. The `Build LifeOS APK` workflow runs automatically, or you can open **Actions → Build LifeOS APK → Run workflow**.
4. The workflow uses `scripts/generate_launcher_icons.py` to generate the correct Android density resources from your image before compiling. Download the `LifeOS-debug-apk` artifact from the successful workflow run.
5. If `app-icon.png` is absent, the build uses a generated fallback icon instead of failing.

Your supplied LifeOS icon is included in this ZIP as `app-icon.png` at the repository root. The GitHub Actions workflow automatically generates Android launcher icon sizes from this image before building the APK. You do not need to upload a separate icon file.

## Workflow path

`.github/workflows/build-LifeOS.yml`

The workflow runs on pushes to `main` and supports manual runs through `workflow_dispatch`. It builds `app/build/outputs/apk/debug/app-debug.apk` and publishes it as the `LifeOS-debug-apk` artifact.
